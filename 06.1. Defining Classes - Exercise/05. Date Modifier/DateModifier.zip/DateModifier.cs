﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Date_Modifier
{
    public static class DateModifier
    {
        public static int DifferenceBetweenTwoDates(string startDateString, string endDateString)
        {
            DateTime startDate = DateTime.Parse(startDateString);
            DateTime endDate = DateTime.Parse(endDateString);

            TimeSpan timeSpan = endDate - startDate;

            return Math.Abs(timeSpan.Days);
        }
    }
}
